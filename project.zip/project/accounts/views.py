from django.shortcuts import render, redirect
from .forms import UserRegisterationForm
from django.contrib.auth import login, logout, authenticate

# Create your views here.
def home(request):
    return render(request, 'accounts/home.html')
def register(request):
    if request.method == 'POST':
        form=UserRegisterationForm(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('home')
    else:
        form=UserRegisterationForm()
    return render(request, 'accounts/register.html')

def login_view(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
    else:
        return render(request, 'accounts/login.html')

def logout_view(request):
    logout(request)
    return redirect('home')

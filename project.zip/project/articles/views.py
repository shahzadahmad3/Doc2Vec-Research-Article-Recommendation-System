from django.shortcuts import render
from .models import Article
from .doc2vec import generate_document_embeddings, calculate_cosine_similarity, get_similar_articles
import numpy as np
# Create your views here.

def home(request):
    return render(request, 'articles/home.html')

def recommend_articles(request, article_id):
    # Generate document embeddings if not already done
    if not Article.objects.filter(embedding__isnull=False).exists():
        generate_document_embeddings()
    
    # Fetch all article embeddings
    articles = Article.objects.all()
    embeddings = [article.embedding for article in articles if article.embedding]
    
    if not embeddings:
        return render(request, 'articles/recommendations.html', {'error': 'No embeddings available.'})
    
    # Calculate cosine similarity matrix
    similarity_matrix = calculate_cosine_similarity(np.array(embeddings))
    
    # Get similar articles
    similar_articles = get_similar_articles(article_id, similarity_matrix)
    
    context = {
        'similar_articles': similar_articles,
        'article_id': article_id
    }
    
    return render(request, 'articles/recommendations.html', context)

def article_detail(request, article_id):
    article = Article.objects.get(paper_id=article_id)
    embeddings=generate_document_embeddings()
    similarity_matrix=calculate_cosine_similarity(np.array(embeddings))
    similar_articles=get_similar_articles(article_id, similarity_matrix)
    return render(request, 'articles/article_detail.html', {'article': article, 'similar_articles': similar_articles})

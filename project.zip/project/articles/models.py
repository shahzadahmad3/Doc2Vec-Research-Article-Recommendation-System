from django.db import models

# Create your models here.
class Article(models.Model):
    paper_id=models.CharField(max_length=100)
    paper_title=models.CharField(max_length=255)
    author_keywords=models.TextField()
    abstract=models.TextField()
    area=models.CharField(max_length=255)
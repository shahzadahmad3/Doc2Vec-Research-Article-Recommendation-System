from transformers import AutoModel, AutoTokenizer
import torch
from .models import Article
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np


model_name="bert-base-uncased"
model=AutoModel.from_pretrained(model_name)
tokenizer=AutoTokenizer.from_pretrained(model_name)

def get_document_embedding(text):
    inputs=tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
    with torch.no_grad():
        outputs=model(**inputs)
    embeddings=outputs.last_hidden_state.mean(dim=1).squeeze()
    return embeddings.numpy()
def generate_document_embeddings():
    articles=Article.objects.all()
    for article in articles:
        embedding=get_document_embedding(article.content)
        article.embedding=embedding.tolist()
        article.save()
    print("Document embeddings generated and saved.")

def calculate_cosine_similarity(embeddings):
    similarity_matrix=cosine_similarity(embeddings)
    return similarity_matrix    

def get_similar_articles(article_id, similarity_matrix, top_n=5):
    article_index=Article.objects.get(paper_id=article_id).id - 1
    similarity_scores=list(enumerate(similarity_matrix[article_index]))
    similarity_scores=sorted(similarity_scores, key=lambda x: x[1], reverse=True)
    similar_articles=[]
    for i in range(1, top_n + 1):
        similar_article_index=similarity_scores[i][0]
        similar_article=Article.objects.get(id=similar_article_index + 1)
        similar_articles.append((similar_article.paper_id, similarity_scores[i][1]))
    return similar_articles